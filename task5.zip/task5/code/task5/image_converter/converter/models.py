from django.db import models

class UploadedImage(models.Model):
    original_image = models.ImageField(upload_to='images/original/')
    bw_image = models.ImageField(upload_to='images/bw/', blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
