from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import ImageUploadForm
from .models import UploadedImage
from PIL import Image
import os

def upload_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_image = form.save(commit=False)
            original_image = Image.open(uploaded_image.original_image)
            bw_image = original_image.convert('L')

            bw_image_path = f'images/bw/{uploaded_image.original_image.name}'
            bw_image.save(os.path.join('media', bw_image_path))

            uploaded_image.bw_image = bw_image_path
            uploaded_image.save()
            return HttpResponse("Image uploaded and converted successfully!")
    else:
        form = ImageUploadForm()
    return render(request, 'upload.html', {'form': form})

def homepage(request):
    return render(request, 'homepage.html') 